package com.example.clint.myapplication;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;


public class MainActivity extends AppCompatActivity {
private EditText totoastText ;

    private  Button clearButton;
    private  Button toastButton;
    private ButtonOnClickListener buttonListen;
    private ButtonHintOnLongClick buttonHintListen ;
private ListView listview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        totoastText = (EditText) findViewById(R.id.editText) ;
        totoastText.setOnClickListener(new TextOnClickListener());
        clearButton  = (Button) findViewById(R.id.BtnClear);
        toastButton = (Button) findViewById(R.id.BtnT);
        listview = (ListView) findViewById(R.id.List);
listview.setAdapter(new ArrayAdapter<String>(this,
        android.R.layout.simple_list_item_1 ,
        getResources().getStringArray(R.array.list_objects)));

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override

            public void onItemClick(AdapterView<?> parent , View view , int position , long id ){
                Toast.makeText(view.getContext() , (String) parent.getAdapter().getItem(position),Toast.LENGTH_LONG).show();
            }
        });




    }

    private class TextOnClickListener implements View.OnClickListener{
@Override

        public  void onClick(View v){
buttonListen = new ButtonOnClickListener();
    buttonHintListen = new ButtonHintOnLongClick();
    clearButton.setOnClickListener(buttonListen);
    toastButton.setOnClickListener(buttonListen);

    clearButton.setOnLongClickListener(buttonHintListen);
    toastButton.setOnLongClickListener(buttonHintListen);



}



    }

    private class ButtonOnClickListener implements View.OnClickListener{

        @Override
        public void onClick(View v){
if (    v.getId() == R.id.BtnClear){
    totoastText.setText("");
}
else if (v.getId() == R.id.BtnT){

    Toast.makeText(v.getContext(),totoastText.getText().toString() , Toast.LENGTH_LONG ).show();
}
else if (v.getId() == R.id.BtnAdd){

    totoastText.setText("Item added");
}


        }
    }

    private class ButtonHintOnLongClick implements  View.OnLongClickListener {


        public boolean onLongClick(View v) {
            String hint = null;
            Context context = v.getContext();

            if (v.getId() == R.id.BtnClear) {

                hint = "This button will clear the text in the above text field";
            } else if (v.getId() == R.id.BtnT) {
                hint = "This button will Toast the text in the above text field";
            }
            Toast.makeText(context, hint, Toast.LENGTH_LONG).show();
            return true;
        }

    }
}
